import tkinter as tk
from tkinter import ttk
from tkinter import  *
def show():

    tempList = [['Jim', '0.33'], ['Dave', '0.67'], ['James', '0.67'], ['Eden', '0.5']]
    tempList.sort(key=lambda e: e[1], reverse=True)

    for i, (name, score) in enumerate(tempList, start=1):
        listBox.insert("", "end", values=(i, name, score))

scores = tk.Tk()
label = Label(scores, text="Discard A Book", font=("Arial",20)).grid(row=0, columnspan=3)

book_id = Label(scores, text="Book ID:", font='Verdana 15 bold').grid(row=1,columnspan=1)
book_id_entry= Entry(scores, width=25).grid(row=1,columnspan=2)

# create Treeview with 3 columns
cols = ("Code", "Title", "Author", "Stock", "Category")
listBox = ttk.Treeview(scores, columns=cols, show='headings')
# set column headings
for col in cols:
    listBox.heading(col, text=col)
listBox.grid(row=2, column=0, columnspan=2)

showScores = tk.Button(scores, text="Show scores", width=15, command='').grid(row=5, column=0)
closeButton = tk.Button(scores, text="Close", width=15, command=exit).grid(row=5, column=1)

scores.mainloop()