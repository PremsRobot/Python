from tkinter import *
from tkinter import messagebox
import pymysql

'''
Update Password Function
'''
def updatePassword():
    def updatelogic():
        if userentry.get() == "" or oldentry.get() == "" or newentry.get() == "" or confirmentry.get() == "":
            messagebox.showerror("Error", "Please enter all the vaild details", parent=up)
        else:
            try:
                con = pymysql.connect(host="localhost", user="root", password="root1234", database="sys")
                cur = con.cursor()

                cur.execute("select * from librarian where librarian_name=%s and librarian_password=%s",
                            (userentry.get(), oldentry.get()))
                row = cur.fetchone()

                if row == None:
                    messagebox.showerror("Error", "Invalid Username And Password", parent=up)

                if newentry.get() != confirmentry.get():
                    messagebox.showerror("Error", "new and confirm password not matched", parent=up)

                else:
                    cur.execute("Update librarian set librarian_password=%s  where librarian_name=%s ",
                                (newentry.get(), userentry.get()))
                    con.commit()
                    messagebox.showinfo("Success", "Password updated successfully!", parent=up)
                    up.destroy()  # close login window
                    # calling menu
                con.close()  # close the connection of database
            except Exception as es:
                messagebox.showerror("Error", f"Error Due to : {str(es)}", parent=up)

    up = Tk()
    up.title("Update Password!")
    up.maxsize(width=500, height=500)
    up.minsize(width=500, height=500)

    username = Label(up, text="Username:", font='Verdana 10 bold')
    username.place(x=80, y=220)

    oldpass = Label(up, text="Old password:", font='Verdana 10 bold')
    oldpass.place(x=80, y=260)

    newpass = Label(up, text="New password;", font='Verdana 10 bold')
    newpass.place(x=80, y=300)

    confirmpass = Label(up, text="Confirm password:", font='Verdana 10 bold')
    confirmpass.place(x=80, y=340)

    # Valid entry checking
    userentry = Entry(up, width=20)
    userentry.place(x=300, y=220)
    #
    oldentry = Entry(up, width=20)
    oldentry.place(x=300, y=260)

    newentry = Entry(up, width=20)
    newentry.place(x=300, y=300)

    confirmentry = Entry(up, width=20)
    confirmentry.place(x=300, y=340)

    # Update logic

    btn_conform = Button(up, text="Confirm", font='Verdana 10 bold', command=updatelogic)
    btn_conform.place(x=175, y=450)
    up.mainloop()